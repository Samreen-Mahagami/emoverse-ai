import boto3
import json
import logging
import time
import random
from concurrent.futures import ThreadPoolExecutor, as_completed

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    Orchestrate the generation of stories, quizzes, and lesson plans with retry logic
    """
    
    lambda_client = boto3.client('lambda')
    
    try:
        # Extract common parameters
        extracted_text = event.get('extracted_text', '')
        grade_level = event.get('grade_level', 'Grade 5')
        emotions = event.get('emotions', {})
        
        # Content generation parameters
        story_theme = event.get('story_theme', 'friendship')
        quiz_type = event.get('quiz_type', 'multiple_choice')
        subject = event.get('subject', 'General')
        
        logger.info(f"Starting content generation for {grade_level}")
        
        # Prepare payloads for each Lambda function
        story_payload = {
            'extracted_text': extracted_text,
            'grade_level': grade_level,
            'story_theme': story_theme,
            'emotions': emotions
        }
        
        quiz_payload = {
            'extracted_text': extracted_text,
            'grade_level': grade_level,
            'quiz_type': quiz_type,
            'num_questions': 5,
            'emotions': emotions
        }
        
        lesson_payload = {
            'extracted_text': extracted_text,
            'grade_level': grade_level,
            'subject': subject,
            'lesson_duration': '45 minutes',
            'emotions': emotions
        }
        
        # Function names
        functions = {
            'story': 'sel-story-generator',
            'quiz': 'sel-quiz-generator', 
            'lesson': 'SEL-lesson-planner'
        }
        
        payloads = {
            'story': story_payload,
            'quiz': quiz_payload,
            'lesson': lesson_payload
        }
        
        # Execute all functions in parallel with retry logic
        results = {}
        
        def invoke_lambda_with_retry(content_type):
            """
            Invoke Lambda function with exponential backoff retry for throttling
            """
            max_retries = 3
            base_delay = 2
            
            for attempt in range(max_retries + 1):
                try:
                    logger.info(f"Invoking {content_type} generator (attempt {attempt + 1})")
                    
                    response = lambda_client.invoke(
                        FunctionName=functions[content_type],
                        InvocationType='RequestResponse',
                        Payload=json.dumps(payloads[content_type])
                    )
                    
                    result = json.loads(response['Payload'].read())
                    
                    # Check if the result contains a throttling error in the response body
                    if 'body' in result and result.get('statusCode') == 500:
                        try:
                            body = json.loads(result['body']) if isinstance(result['body'], str) else result['body']
                            if 'error' in body and ('ThrottlingException' in str(body['error']) or 'Too many requests' in str(body['error'])):
                                if attempt < max_retries:
                                    delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
                                    logger.info(f"Throttling detected for {content_type}, retrying in {delay:.1f}s (attempt {attempt + 1}/{max_retries})")
                                    time.sleep(delay)
                                    continue
                                else:
                                    logger.error(f"Max retries exceeded for {content_type} due to throttling")
                                    return content_type, {'error': f'Max retries exceeded due to throttling: {body["error"]}'}
                        except (json.JSONDecodeError, KeyError):
                            pass
                    
                    # Success case
                    logger.info(f"{content_type} generation completed successfully")
                    return content_type, result
                    
                except Exception as e:
                    error_str = str(e)
                    if ('ThrottlingException' in error_str or 'Too many requests' in error_str) and attempt < max_retries:
                        delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
                        logger.info(f"Throttling exception for {content_type}, retrying in {delay:.1f}s (attempt {attempt + 1}/{max_retries})")
                        time.sleep(delay)
                        continue
                    else:
                        logger.error(f"Error invoking {content_type} generator: {error_str}")
                        return content_type, {'error': error_str}
            
            return content_type, {'error': f'Max retries exceeded for {content_type}'}
        
        # Use ThreadPoolExecutor for parallel execution with retry logic
        with ThreadPoolExecutor(max_workers=3) as executor:
            future_to_type = {
                executor.submit(invoke_lambda_with_retry, content_type): content_type 
                for content_type in functions.keys()
            }
            
            for future in as_completed(future_to_type):
                content_type, result = future.result()
                results[content_type] = result
                logger.info(f"{content_type} processing completed")
        
        # Analyze results
        successful_generations = []
        failed_generations = []
        
        for content_type, result in results.items():
            if 'error' in result or (isinstance(result, dict) and result.get('statusCode') == 500):
                failed_generations.append(content_type)
            else:
                successful_generations.append(content_type)
        
        # Log summary
        logger.info(f"Generation summary - Success: {successful_generations}, Failed: {failed_generations}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Content generation completed',
                'results': results,
                'grade_level': grade_level,
                'summary': {
                    'successful_generations': successful_generations,
                    'failed_generations': failed_generations,
                    'total_requested': len(functions),
                    'success_count': len(successful_generations),
                    'failure_count': len(failed_generations)
                },
                'generated_content': {
                    'story_generated': 'story' in successful_generations,
                    'quiz_generated': 'quiz' in successful_generations,
                    'lesson_generated': 'lesson' in successful_generations
                }
            })
        }
        
    except Exception as e:
        logger.error(f"Orchestrator error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'message': 'Content generation orchestration failed'
            })
        }
